package com.example.outven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutvenApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutvenApplication.class, args);
	}

}
